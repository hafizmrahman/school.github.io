
   var r = document.querySelector(':root');
 function show() {
  r.style.setProperty('--hide', 'block');
}
function hide() {
    r.style.setProperty('--hide','')
}